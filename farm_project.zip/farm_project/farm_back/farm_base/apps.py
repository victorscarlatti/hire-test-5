from django.apps import AppConfig


class FarmConfig(AppConfig):
    name = 'farm_base'
    verbose_name = "Farm Project - Base"
