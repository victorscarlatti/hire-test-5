from .farm import FarmRetrieveUpdateDestroyView, FarmListCreateView
from .owner import OwnerListCreateView, OwnerRetrieveUpdateDestroyView
